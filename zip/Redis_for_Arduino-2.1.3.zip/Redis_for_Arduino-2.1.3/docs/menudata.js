var menudata={children:[
{text:"Home",url:"index.html"},
{text:"Primary Documentation",url:"classRedis.html"},
{text:"Latest Release",url:"https://github.com/electric-sheep-co/arduino-redis/releases/latest"},
{text:"README",url:"md_README.html"},
{text:"Classes",url:"annotated.html",children:[
{text:"Class List",url:"annotated.html"},
{text:"Class Index",url:"classes.html"},
{text:"Class Hierarchy",url:"inherits.html"}]},
{text:"File List",url:"files.html"},
{text:"GitHub",url:"https://github.com/electric-sheep-co/arduino-redis"}]}
