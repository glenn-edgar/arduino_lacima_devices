var searchData=
[
  ['append',['append',['../classRedis.html#aff7468b0f29b883576227a60b86a2a2d',1,'Redis']]],
  ['authenticate',['authenticate',['../classRedis.html#a8f9a19a438e2f005852dcc7cd46816e5',1,'Redis']]],
  ['arduino_2dredis',['Arduino-Redis',['../index.html',1,'']]],
  ['arduino_20redis_20library',['Arduino Redis Library',['../md_README.html',1,'']]]
];
