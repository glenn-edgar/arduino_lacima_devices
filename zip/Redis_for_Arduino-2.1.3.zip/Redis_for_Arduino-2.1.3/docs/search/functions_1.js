var searchData=
[
  ['del',['del',['../classRedis.html#ad3048eb52ab9d95237226959e6be34da',1,'Redis']]]
];
