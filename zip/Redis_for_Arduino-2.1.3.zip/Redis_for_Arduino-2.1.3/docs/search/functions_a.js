var searchData=
[
  ['set',['set',['../classRedis.html#ad9e9c063e541c430e44861787d036118',1,'Redis']]]
];
