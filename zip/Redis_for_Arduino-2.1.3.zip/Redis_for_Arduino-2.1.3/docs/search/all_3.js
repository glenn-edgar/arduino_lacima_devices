var searchData=
[
  ['get',['get',['../classRedis.html#ad8930ca58b3575824116e53fcff809e8',1,'Redis']]]
];
