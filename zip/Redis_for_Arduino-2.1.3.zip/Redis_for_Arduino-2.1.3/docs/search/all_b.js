var searchData=
[
  ['ttl',['ttl',['../classRedis.html#a9ff7a6dceacb137d2f9ea0f012085b69',1,'Redis']]],
  ['type',['Type',['../classRedisObject.html#a53709bcd6c9b9172f48520323bf8cafe',1,'RedisObject']]]
];
