var searchData=
[
  ['type',['Type',['../classRedisObject.html#a53709bcd6c9b9172f48520323bf8cafe',1,'RedisObject']]]
];
