var searchData=
[
  ['operator_20string',['operator String',['../classRedisObject.html#ae78351c3a7534104868495077cb96fd7',1,'RedisObject']]]
];
