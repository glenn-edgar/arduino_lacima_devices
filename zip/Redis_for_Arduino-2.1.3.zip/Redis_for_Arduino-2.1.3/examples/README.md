### Examples
- `Pub_Sub`: An example of publish application with the Redis library.
- `Simple`: Open the connection, set and get a key then close the connection.
- `JsonPub`: A simple example demonstrating periodic JSON publications (with a non-blocking loop()); requires ArduinoJson library.
