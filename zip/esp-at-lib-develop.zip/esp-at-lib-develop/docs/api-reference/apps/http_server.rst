.. _api_app_http_server:

HTTP Server
===========

.. doxygengroup:: ESP_APP_HTTP_SERVER
.. doxygengroup:: ESP_APP_HTTP_SERVER_FS_FAT