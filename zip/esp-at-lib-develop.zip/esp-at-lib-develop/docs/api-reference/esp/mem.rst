.. _api_esp_mem:

Memory manager
==============

.. doxygengroup:: ESP_MEM