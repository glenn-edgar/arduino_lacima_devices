#ifndef SNIPPET_HDR_TELNET_SERVER_H
#define SNIPPET_HDR_TELNET_SERVER_H

#ifdef __cplusplus
extern "C" {
#endif

void telnet_server_thread(void const* arg);

#ifdef __cplusplus
}
#endif

#endif
