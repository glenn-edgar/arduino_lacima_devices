#ifndef SNIPPET_HDR_SNTP_H
#define SNIPPET_HDR_SNTP_H

#ifdef __cplusplus
extern "C" {
#endif

void sntp_gettime(void);

#ifdef __cplusplus
}
#endif

#endif
